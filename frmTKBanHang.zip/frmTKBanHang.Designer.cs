﻿
namespace Quan_Ly_Hieu_Thuoc
{
    partial class frmTKBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.grvTK = new Guna.UI2.WinForms.Guna2DataGridView();
            this.mahd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thoigian = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mathuoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenthuoc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenkh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soluongban = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donvi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giaban = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tongtien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTimkiem = new Guna.UI2.WinForms.Guna2Button();
            this.cbthoigian = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbTenthuoc = new Guna.UI2.WinForms.Guna2CheckBox();
            this.dtTime = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTenthuoc = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.cbTenKH = new Guna.UI2.WinForms.Guna2CheckBox();
            this.txtTenKH = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.grvTK)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // grvTK
            // 
            this.grvTK.AllowUserToResizeRows = false;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.grvTK.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle33;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(113)))), ((int)(((byte)(46)))));
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(113)))), ((int)(((byte)(46)))));
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grvTK.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.grvTK.ColumnHeadersHeight = 40;
            this.grvTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.grvTK.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mahd,
            this.thoigian,
            this.mathuoc,
            this.tenthuoc,
            this.tenkh,
            this.soluongban,
            this.donvi,
            this.giaban,
            this.tongtien});
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grvTK.DefaultCellStyle = dataGridViewCellStyle35;
            this.grvTK.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.grvTK.Location = new System.Drawing.Point(16, 217);
            this.grvTK.Margin = new System.Windows.Forms.Padding(4);
            this.grvTK.Name = "grvTK";
            this.grvTK.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grvTK.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.grvTK.RowHeadersVisible = false;
            this.grvTK.RowHeadersWidth = 51;
            this.grvTK.RowTemplate.Height = 25;
            this.grvTK.Size = new System.Drawing.Size(1146, 513);
            this.grvTK.TabIndex = 69;
            this.grvTK.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.AlternatingRowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvTK.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grvTK.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.grvTK.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.grvTK.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(113)))), ((int)(((byte)(46)))));
            this.grvTK.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.grvTK.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvTK.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.grvTK.ThemeStyle.HeaderStyle.Height = 40;
            this.grvTK.ThemeStyle.ReadOnly = false;
            this.grvTK.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.grvTK.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grvTK.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.grvTK.ThemeStyle.RowsStyle.Height = 25;
            this.grvTK.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.White;
            this.grvTK.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // mahd
            // 
            this.mahd.DataPropertyName = "mahd";
            this.mahd.HeaderText = "Mã hóa đơn";
            this.mahd.MinimumWidth = 6;
            this.mahd.Name = "mahd";
            // 
            // thoigian
            // 
            this.thoigian.DataPropertyName = "thoigian";
            this.thoigian.HeaderText = "Thời gian";
            this.thoigian.MinimumWidth = 6;
            this.thoigian.Name = "thoigian";
            // 
            // mathuoc
            // 
            this.mathuoc.DataPropertyName = "mathuoc";
            this.mathuoc.HeaderText = "Mã thuốc";
            this.mathuoc.MinimumWidth = 6;
            this.mathuoc.Name = "mathuoc";
            // 
            // tenthuoc
            // 
            this.tenthuoc.DataPropertyName = "tenthuoc";
            this.tenthuoc.HeaderText = "Tên thuốc";
            this.tenthuoc.MinimumWidth = 6;
            this.tenthuoc.Name = "tenthuoc";
            // 
            // tenkh
            // 
            this.tenkh.DataPropertyName = "tenkh";
            this.tenkh.HeaderText = "Tên khách hàng";
            this.tenkh.MinimumWidth = 6;
            this.tenkh.Name = "tenkh";
            // 
            // soluongban
            // 
            this.soluongban.DataPropertyName = "soluongban";
            this.soluongban.HeaderText = "Số lượng bán";
            this.soluongban.MinimumWidth = 6;
            this.soluongban.Name = "soluongban";
            // 
            // donvi
            // 
            this.donvi.DataPropertyName = "donvi";
            this.donvi.HeaderText = "Đơn vị";
            this.donvi.MinimumWidth = 6;
            this.donvi.Name = "donvi";
            // 
            // giaban
            // 
            this.giaban.DataPropertyName = "giaban";
            this.giaban.HeaderText = "Đơn giá";
            this.giaban.MinimumWidth = 6;
            this.giaban.Name = "giaban";
            // 
            // tongtien
            // 
            this.tongtien.DataPropertyName = "tongtien";
            this.tongtien.HeaderText = "Tổng tiền";
            this.tongtien.MinimumWidth = 6;
            this.tongtien.Name = "tongtien";
            // 
            // btnTimkiem
            // 
            this.btnTimkiem.AutoRoundedCorners = true;
            this.btnTimkiem.BorderRadius = 19;
            this.btnTimkiem.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTimkiem.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTimkiem.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTimkiem.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTimkiem.Enabled = false;
            this.btnTimkiem.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnTimkiem.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnTimkiem.ForeColor = System.Drawing.Color.White;
            this.btnTimkiem.Image = global::Quan_Ly_Hieu_Thuoc.Properties.Resources.magnifying_glass;
            this.btnTimkiem.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTimkiem.Location = new System.Drawing.Point(822, 105);
            this.btnTimkiem.Margin = new System.Windows.Forms.Padding(4);
            this.btnTimkiem.Name = "btnTimkiem";
            this.btnTimkiem.Size = new System.Drawing.Size(152, 41);
            this.btnTimkiem.TabIndex = 42;
            this.btnTimkiem.Text = "TÌM KIẾM";
            this.btnTimkiem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTimkiem.Click += new System.EventHandler(this.btnTimkiem_Click);
            // 
            // cbthoigian
            // 
            this.cbthoigian.AutoSize = true;
            this.cbthoigian.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbthoigian.CheckedState.BorderRadius = 0;
            this.cbthoigian.CheckedState.BorderThickness = 0;
            this.cbthoigian.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cbthoigian.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.cbthoigian.Location = new System.Drawing.Point(15, 140);
            this.cbthoigian.Margin = new System.Windows.Forms.Padding(4);
            this.cbthoigian.Name = "cbthoigian";
            this.cbthoigian.Size = new System.Drawing.Size(87, 23);
            this.cbthoigian.TabIndex = 58;
            this.cbthoigian.Text = "Thời gian";
            this.cbthoigian.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbthoigian.UncheckedState.BorderRadius = 0;
            this.cbthoigian.UncheckedState.BorderThickness = 0;
            this.cbthoigian.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbthoigian.CheckedChanged += new System.EventHandler(this.cbthoigian_CheckedChanged);
            // 
            // cbTenthuoc
            // 
            this.cbTenthuoc.AutoSize = true;
            this.cbTenthuoc.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbTenthuoc.CheckedState.BorderRadius = 0;
            this.cbTenthuoc.CheckedState.BorderThickness = 0;
            this.cbTenthuoc.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.cbTenthuoc.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.cbTenthuoc.Location = new System.Drawing.Point(16, 60);
            this.cbTenthuoc.Margin = new System.Windows.Forms.Padding(4);
            this.cbTenthuoc.Name = "cbTenthuoc";
            this.cbTenthuoc.Size = new System.Drawing.Size(91, 23);
            this.cbTenthuoc.TabIndex = 56;
            this.cbTenthuoc.Text = "Tên thuốc";
            this.cbTenthuoc.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbTenthuoc.UncheckedState.BorderRadius = 0;
            this.cbTenthuoc.UncheckedState.BorderThickness = 0;
            this.cbTenthuoc.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbTenthuoc.CheckedChanged += new System.EventHandler(this.cbTenthuoc_CheckedChanged_1);
            // 
            // dtTime
            // 
            this.dtTime.AutoRoundedCorners = true;
            this.dtTime.BorderRadius = 17;
            this.dtTime.Checked = true;
            this.dtTime.Enabled = false;
            this.dtTime.FillColor = System.Drawing.SystemColors.Control;
            this.dtTime.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTime.Location = new System.Drawing.Point(126, 132);
            this.dtTime.Margin = new System.Windows.Forms.Padding(4);
            this.dtTime.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtTime.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtTime.Name = "dtTime";
            this.dtTime.Size = new System.Drawing.Size(176, 37);
            this.dtTime.TabIndex = 64;
            this.dtTime.Value = new System.DateTime(2023, 3, 27, 14, 23, 13, 396);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTenKH);
            this.groupBox1.Controls.Add(this.cbTenKH);
            this.groupBox1.Controls.Add(this.txtTenthuoc);
            this.groupBox1.Controls.Add(this.dtTime);
            this.groupBox1.Controls.Add(this.cbthoigian);
            this.groupBox1.Controls.Add(this.cbTenthuoc);
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(742, 194);
            this.groupBox1.TabIndex = 66;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm kiếm theo";
            // 
            // txtTenthuoc
            // 
            this.txtTenthuoc.BorderRadius = 21;
            this.txtTenthuoc.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenthuoc.DefaultText = "";
            this.txtTenthuoc.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTenthuoc.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTenthuoc.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenthuoc.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenthuoc.Enabled = false;
            this.txtTenthuoc.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenthuoc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTenthuoc.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenthuoc.Location = new System.Drawing.Point(127, 46);
            this.txtTenthuoc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenthuoc.Name = "txtTenthuoc";
            this.txtTenthuoc.PasswordChar = '\0';
            this.txtTenthuoc.PlaceholderText = "";
            this.txtTenthuoc.SelectedText = "";
            this.txtTenthuoc.Size = new System.Drawing.Size(176, 44);
            this.txtTenthuoc.TabIndex = 65;
            // 
            // cbTenKH
            // 
            this.cbTenKH.AutoSize = true;
            this.cbTenKH.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbTenKH.CheckedState.BorderRadius = 0;
            this.cbTenKH.CheckedState.BorderThickness = 0;
            this.cbTenKH.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbTenKH.Location = new System.Drawing.Point(399, 63);
            this.cbTenKH.Name = "cbTenKH";
            this.cbTenKH.Size = new System.Drawing.Size(74, 20);
            this.cbTenKH.TabIndex = 66;
            this.cbTenKH.Text = "Tên KH";
            this.cbTenKH.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbTenKH.UncheckedState.BorderRadius = 0;
            this.cbTenKH.UncheckedState.BorderThickness = 0;
            this.cbTenKH.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbTenKH.CheckedChanged += new System.EventHandler(this.cbTenKH_CheckedChanged);
            // 
            // txtTenKH
            // 
            this.txtTenKH.BorderRadius = 21;
            this.txtTenKH.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTenKH.DefaultText = "";
            this.txtTenKH.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtTenKH.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtTenKH.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenKH.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtTenKH.Enabled = false;
            this.txtTenKH.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenKH.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTenKH.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtTenKH.Location = new System.Drawing.Point(506, 46);
            this.txtTenKH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.PasswordChar = '\0';
            this.txtTenKH.PlaceholderText = "";
            this.txtTenKH.SelectedText = "";
            this.txtTenKH.Size = new System.Drawing.Size(203, 44);
            this.txtTenKH.TabIndex = 67;
            // 
            // frmTKBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 743);
            this.Controls.Add(this.grvTK);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnTimkiem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmTKBanHang";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmTKBanHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grvTK)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DataGridView grvTK;
        private System.Windows.Forms.GroupBox groupBox1;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtTime;
        private Guna.UI2.WinForms.Guna2CheckBox cbthoigian;
        private Guna.UI2.WinForms.Guna2CheckBox cbTenthuoc;
        private Guna.UI2.WinForms.Guna2Button btnTimkiem;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        private System.Windows.Forms.DataGridViewTextBoxColumn mahd;
        private System.Windows.Forms.DataGridViewTextBoxColumn thoigian;
        private System.Windows.Forms.DataGridViewTextBoxColumn mathuoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenthuoc;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenkh;
        private System.Windows.Forms.DataGridViewTextBoxColumn soluongban;
        private System.Windows.Forms.DataGridViewTextBoxColumn donvi;
        private System.Windows.Forms.DataGridViewTextBoxColumn giaban;
        private System.Windows.Forms.DataGridViewTextBoxColumn tongtien;
        private Guna.UI2.WinForms.Guna2TextBox txtTenthuoc;
        private Guna.UI2.WinForms.Guna2CheckBox cbTenKH;
        private Guna.UI2.WinForms.Guna2TextBox txtTenKH;
    }
}